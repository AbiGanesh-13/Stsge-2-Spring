package com.example.order_service.service;

import com.example.order_service.entity.Order;

public interface OrderService {
	
	public Order placeOrder(Order order);

}
