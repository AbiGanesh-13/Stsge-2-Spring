package com.example.order_service.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.reactive.function.client.WebClient;

import com.example.order_service.dto.OrderResponseDTO;
import com.example.order_service.dto.ProductDTO;
import com.example.order_service.entity.Order;
import com.example.order_service.repository.OrderRepository;
import com.example.order_service.service.OrderService;

import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/orders")
public class OrderController {

    private final OrderRepository orderRepository;
	@Autowired
	private OrderService orderService;
	@Autowired
	private WebClient.Builder webClientBuilder;

    OrderController(OrderRepository orderRepository) {
        this.orderRepository = orderRepository;
    }
	
	//create method for place order
	@PostMapping("placeOrder")
	public Mono<ResponseEntity<OrderResponseDTO>> placeOrder(@RequestBody Order order){
		//fetch product details from product service
		return webClientBuilder.build().get().uri("http://localhost:8082/products/getProduct/"+order.getProductId()).retrieve()
				.bodyToMono(ProductDTO.class).map(productDTO->{
					OrderResponseDTO orderResponseDTO=new OrderResponseDTO();
					orderResponseDTO.setProductId(order.getProductId());
					orderResponseDTO.setQuantity(order.getQuantity());
					
					//set product details
					orderResponseDTO.setProductName(productDTO.getName());
					orderResponseDTO.setProductPrice(productDTO.getPrice());
					orderResponseDTO.setTotalPrice(order.getQuantity()*productDTO.getPrice());
					
					//save order details to DB
					orderRepository.save(order);
					orderResponseDTO.setOrderId(order.getId());
					return ResponseEntity.ok(orderResponseDTO);
					
				});
		
	}
	
	//Get All orders
	@GetMapping("/getAllOrders")
	public List<Order> getAllOrders(){
		return orderRepository.findAll();
				
	}
	
	

}
