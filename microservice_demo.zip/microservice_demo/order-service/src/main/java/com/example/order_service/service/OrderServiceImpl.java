package com.example.order_service.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.order_service.entity.Order;
import com.example.order_service.repository.OrderRepository;

@Service
public class OrderServiceImpl implements OrderService{
@Autowired
	private OrderRepository orderRepository;
	@Override
	public Order placeOrder(Order order) {
		return orderRepository.save(order);
	}

}
