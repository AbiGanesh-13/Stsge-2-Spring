package com.example.product_service.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.product_service.entity.Product;
import com.example.product_service.service.ProductService;

@RestController
@RequestMapping("/products")
public class ProductController {
	@Autowired
	private ProductService service;

//creating a product
	@PostMapping("/create")
	public ResponseEntity<Product> createProduct(@RequestBody Product product) {
		service.createProduct(product);
		return new ResponseEntity<Product>(product, HttpStatus.ACCEPTED);
	}
	
	//fetching the products
	@GetMapping("/getAllProducts")
	public ResponseEntity<List<Product>> getAllProducts(){
		List<Product> allProducts = service.getAllProducts();
		return new ResponseEntity<List<Product>>(allProducts, HttpStatus.OK);
	}
	
	//getting product details based on id
	@GetMapping("/getProduct/{id}")
	public ResponseEntity<Product> getById(@PathVariable Long id){
		Product product = service.getById(id);
		return new ResponseEntity<Product>(product, HttpStatus.OK);
	}
	
	
}
