package com.example.product_service.service;

import java.util.List;

import com.example.product_service.entity.Product;

public interface ProductService {
	
	public Product createProduct(Product product);
	public List<Product> getAllProducts();
	public Product getById(Long id);

}
