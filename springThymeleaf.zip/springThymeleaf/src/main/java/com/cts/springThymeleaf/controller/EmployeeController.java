package com.cts.springThymeleaf.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cts.springThymeleaf.entity.Employee;
import com.cts.springThymeleaf.service.EmployeeService;

import jakarta.validation.Valid;

@Controller
public class EmployeeController {
	@Autowired
	private EmployeeService service;

	@GetMapping("/home")
	public String homePage(Model model) {
		model.addAttribute("empList", service.getAllEmployees());
		return "home";
	}

	@GetMapping("/showNewEmployeeForm")
	public String showNewEmployeeForm(Model model) {
		Employee employee = new Employee();
		model.addAttribute("employee", employee);
		return "newEmployee";
	}

	@GetMapping("/showFormForUpdate")
	public String showFormForUpdate(@RequestParam("employeeId") Integer id, Model model) {
		// get the employee from service
		Employee employeeById = service.getEmployeeById(id);
		// set employee in the model to populate the form
		model.addAttribute("employee", employeeById);
		// send over to our form

		return "newEmployee";
	}

	@PostMapping("/saveEmployee")
	public String saveEmployee(@Valid @ModelAttribute("employee") Employee employee, BindingResult result) {
		if (result.hasErrors()) {
			return "newEmployee";
		}
		service.addEmployee(employee);
		return "redirect:/home";
	}

	@GetMapping("/deleteEmployee")
	public String deleteEmployee(@RequestParam("employeeId") Integer id) {
		service.deleteEmployee(id);
		return "redirect:/home";
	}

}
