package com.cts.springThymeleaf.service;

import java.util.List;

import com.cts.springThymeleaf.entity.Employee;

public interface EmployeeService {
	
	public Employee addEmployee(Employee employee);

	public List<Employee> getAllEmployees();
	
	public Employee getEmployeeById(Integer id);
	
	public void deleteEmployee(Integer id);

}
